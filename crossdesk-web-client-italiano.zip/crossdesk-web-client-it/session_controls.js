// Floating controls follow the shared Android/iOS session interaction.
(function () {
  const control = window.CrossDeskControl;
  const session = window.CrossDeskSession;
  const byId = (id) => document.getElementById(id);
  const orb = byId("panel-collapsed-bar");
  const panel = byId("connected-panel");
  const mouse = byId("virtual-mouse");
  const grip = byId("virtual-mouse-grip");
  const keyboard = byId("virtual-keyboard");
  const shield = byId("session-menu-shield");
  if (!orb || !panel || !shield || !control || !session) return;
  const clamp = (n, min, max) => Math.max(min, Math.min(n, Math.max(min, max)));
  const pageTitles = { main: "Controllo remoto", video: "Impostazioni video", network: "Stato rete",
    display: "Monitor", files: "Trasferimento file", clipboard: "Appunti", disconnect: "Disconnetti" };

  class SessionControls {
    constructor() {
      this.active = false;
      this.connected = false;
      this.videoReady = false;
      this.page = "main";
      this.orbPosition = null;
      this.keyboardPosition = null;
      this.mousePosition = null;
      this.mouseVisible = false;
      this.drag = null;
      this.suppressClick = false;
      this.fileRows = new Map();
      this.bindEvents();
      this.renderSettings(null);
      this.renderResolutions(null);
      this.setConnected(false);
      this.renderFiles(window.CrossDeskFiles);
      this.renderClipboard(window.CrossDeskClipboard);
    }

    // Fixed overlays use the visual viewport so browser chrome, zoom and safe
    // areas cannot leave their close buttons outside the usable screen.
    bounds() {
      const viewport = window.visualViewport;
      const style = getComputedStyle(byId("connected-overlay"));
      const inset = (side) => parseFloat(style.getPropertyValue(`--safe-${side}`)) || 0;
      const left = (viewport?.offsetLeft || 0) + inset("left") + 8;
      const top = (viewport?.offsetTop || 0) + inset("top") + 8;
      return { left, top,
        right: (viewport?.offsetLeft || 0) + (viewport?.width || innerWidth) - inset("right") - 8,
        bottom: (viewport?.offsetTop || 0) + (viewport?.height || innerHeight) - inset("bottom") - 8 };
    }

    place(element, x, y, bounds = this.bounds()) {
      const position = { x: clamp(x, bounds.left, bounds.right - element.offsetWidth),
        y: clamp(y, bounds.top, bounds.bottom - element.offsetHeight) };
      Object.assign(element.style, { left: `${position.x}px`, top: `${position.y}px`,
        right: "auto", bottom: "auto", transform: "none" });
      return position;
    }

    layout() {
      if (!this.active) return;
      const b = this.bounds(), width = b.right - b.left, height = b.bottom - b.top;
      const pos = this.orbPosition || { x: b.right - 58, y: b.top + 9 };
      this.orbPosition = this.place(orb, pos.x, pos.y, b);
      const rect = orb.getBoundingClientRect();
      const landscape = height < 400 && width >= 400;
      panel.classList.toggle("session-landscape", landscape);
      panel.style.width = `${Math.min(width, landscape ? 380 : Math.max(280, Math.min(340, width - 144)))}px`;
      panel.style.maxHeight = `${height}px`;
      if (!panel.hidden) {
        const leftSide = rect.left + rect.width / 2 > (b.left + b.right) / 2;
        this.place(panel, leftSide ? rect.left - panel.offsetWidth - 12 : rect.right + 12,
          rect.top + rect.height / 2 - panel.offsetHeight / 2, b);
      }
      keyboard.style.width = `${Math.min(800, width)}px`;
      keyboard.style.maxHeight = `${height}px`;
      keyboard.style.setProperty("--keyboard-height", `${height}px`);
      if (keyboard.style.display !== "none") {
        const kp = this.keyboardPosition || { x: b.left + (width - keyboard.offsetWidth) / 2,
          y: b.bottom - keyboard.offsetHeight };
        this.keyboardPosition = this.place(keyboard, kp.x, kp.y, b);
      }
      if (mouse.style.display !== "none") {
        const preferred = this.mousePosition || { x: b.right - mouse.offsetWidth - 8,
          y: b.bottom - mouse.offsetHeight - 16 };
        const x = clamp(preferred.x, b.left, b.right - mouse.offsetWidth);
        let y = clamp(preferred.y, b.top, b.bottom - mouse.offsetHeight);
        if (keyboard.style.display !== "none") {
          const kb = keyboard.getBoundingClientRect();
          if (x < kb.right && x + mouse.offsetWidth > kb.left &&
              y < kb.bottom && y + mouse.offsetHeight > kb.top) {
            const above = kb.top - mouse.offsetHeight - 6;
            y = above >= b.top ? above : kb.bottom + 6;
          }
        }
        this.place(mouse, x, y, b);
      }
      control.constrainViewport();
    }

    start() {
      this.active = true;
      this.videoReady = false;
      this.mouseVisible = true;
      this.mousePosition = null;
      this.orbPosition = null;
      this.keyboardPosition = null;
      control.setMouseMode("relative");
      control.hideVirtualKeyboard();
      this.close();
    }

    stop() {
      this.filePickerSession = null;
      window.CrossDeskFileManager?.hide();
      this.endDrag(null, true);
      this.close();
      this.active = false;
      this.videoReady = false;
      this.mouseVisible = false;
      this.setConnected(false);
      control.hideVirtualKeyboard();
      control.cancelLocalInput();
      this.updateMouse();
    }

    setConnected(connected) {
      this.connected = connected;
      panel.querySelectorAll("[data-needs-connection]").forEach(button => button.disabled = !connected);
      if (!connected) {
        control.cancelLocalInput();
        control.hideVirtualKeyboard();
      }
      this.updateMouse();
      this.renderResolutions(window.CrossDeskDisplayResolutions);
    }

    setVideoReady() {
      if (!this.active) return;
      this.videoReady = true;
      this.updateMouse();
    }

    showPage(page) {
      if (!pageTitles[page]) return;
      // Match the desktop capability fallback: absent/false means the original
      // file picker and file channels, without opening directory RPC access.
      if (page === "files" && window.CrossDeskFiles?.browser?.supported === true) {
        this.close();
        window.CrossDeskFileManager?.open(window.CrossDeskFiles);
        return;
      }
      control.cancelLocalInput();
      control.lockedPanel.closeMenu();
      this.page = page;
      panel.dataset.page = page;
      panel.hidden = false;
      shield.hidden = false;
      orb.setAttribute("aria-expanded", "true");
      byId("session-menu-title").textContent = pageTitles[page];
      byId("session-menu-back").hidden = page === "main" || page === "disconnect";
      byId("disconnect-connected").hidden = page === "disconnect" || page === "clipboard";
      panel.querySelectorAll("[data-session-page]").forEach(el => el.hidden = el.dataset.sessionPage !== page);
      if (page === "disconnect") control.hideVirtualKeyboard();
      if (page === "files" || page === "clipboard") {
        // Native pickers and editable text need the browser's regular pointer.
        if (document.pointerLockElement) document.exitPointerLock?.();
      }
      this.updateMouse();
      this.renderSettings(window.CrossDeskVideoSettings);
      this.renderResolutions(window.CrossDeskDisplayResolutions);
      this.renderNetwork(window.CrossDeskStats);
      this.renderFiles(window.CrossDeskFiles);
      this.renderClipboard(window.CrossDeskClipboard);
      (page === "disconnect" ? byId("session-disconnect-cancel") : byId("session-menu-close")).focus({ preventScroll: true });
    }

    close() {
      control.lockedPanel.closeMenu();
      panel.hidden = true;
      shield.hidden = true;
      orb.setAttribute("aria-expanded", "false");
      this.page = "main";
      panel.dataset.page = "main";
      this.fileRows.clear();
      byId("file-transfer-list").replaceChildren();
      this.updateMouse();
      if (panel.contains(document.activeElement)) orb.focus({ preventScroll: true });
    }

    updateMouse() {
      const visible = this.active && this.connected && this.videoReady && this.mouseVisible;
      if (!visible && this.drag?.target === mouse) this.endDrag(null, true);
      mouse.style.display = visible ? "flex" : "none";
      byId("session-mouse-label").textContent = this.mouseVisible ? "Nascondi mouse" : "Mouse virtuale";
      byId("session-mouse").setAttribute("aria-pressed", String(this.mouseVisible));
      byId("session-mouse-mode-label").textContent = control.state.mobileControlMode === "relative" ? "Mouse relativo" : "Mouse assoluto";
      this.layout();
    }

    renderClipboard(clipboard) {
      const ready = clipboard?.ready;
      const state = byId("clipboard-state");
      state.hidden = !!ready;
      state.textContent = ready ? "" : clipboard?.state === "unsupported"
        ? "Il dispositivo controllato non supporta la sincronizzazione appunti, il controllo remoto funziona comunque" : clipboard?.closed ? "Connessione interrotta" : "Connessione in corso…";
      byId("clipboard-automatic").disabled = !ready;
      byId("clipboard-automatic").setAttribute("aria-checked", String(!!ready && !!clipboard?.automatic));
      byId("clipboard-permissions").hidden = !ready;
      byId("clipboard-permissions").textContent = !ready ? "" : clipboard?.automatic
        ? (!clipboard.readGranted || !clipboard.writeGranted)
          ? "Permessi limitati, puoi inviare o copiare manualmente" : "Sincronizza automaticamente il testo copiato in questa pagina"
        : "Se attivo, sincronizza il testo copiato in questa pagina";
      byId("clipboard-send-local").disabled = !ready || !!clipboard.pending;
      byId("clipboard-send-text").disabled = !ready || !!clipboard.pending;
      byId("clipboard-copy-remote").disabled = !ready || !clipboard.remoteText;
      const remote = byId("clipboard-remote"), text = clipboard?.remoteText || "";
      if (remote.value !== text) remote.value = text;
      if (clipboard?.closed || this.clipboardSession !== clipboard) {
        byId("clipboard-local").value = "";
        byId("clipboard-manual").open = false;
      }
      this.clipboardSession = clipboard;
      byId("clipboard-feedback").textContent = clipboard?.status || "";
      if (this.page === "clipboard") this.layout();
    }

    showClipboardManual(field) {
      byId("clipboard-manual").open = true;
      this.layout();
      if (this.page === "clipboard" && !panel.hidden)
        byId(field === "receive" ? "clipboard-remote" : "clipboard-local").focus();
    }

    renderSettings(state) {
      const selection = state?.selection || session.defaultVideoSettings;
      panel.querySelectorAll("[data-setting]").forEach(button => {
        button.disabled = !state?.supported;
        button.setAttribute("aria-pressed", String(selection[button.dataset.setting] === Number(button.dataset.value)));
      });
      const failed = ["failed", "rejected", "timeout"].includes(state?.status);
      byId("video-settings-feedback").textContent = !state?.supported
        ? "Regolabile dopo la connessione, richiede supporto del dispositivo controllato."
        : failed ? "Regolazione non riuscita, riprova." : state.status === "pending" ? "Applicazione in corso…" : "";
      byId("video-settings-retry").hidden = !failed || !state?.supported;
      this.layout();
    }

    renderResolutions(resolutions) {
      const select = byId("display-resolution"), raw = byId("display-id").value;
      const display = raw === "" ? null : resolutions?.display(Number(raw));
      const signature = JSON.stringify([display || null, !!resolutions?.ready, !!resolutions?.pending]);
      if (this.resolutionContext?.owner !== resolutions || this.resolutionSignature !== signature) {
        // Invalidate pointer-lock menus whose display/mode snapshot has changed.
        if (control.lockedPanel.menu?.select === select) control.lockedPanel.closeMenu();
        this.resolutionSignature = signature;
        this.resolutionContext = { owner: resolutions, displayId: display?.display_id, displayKey: display?.display_key };
        select.replaceChildren();
        const label = mode => `${mode.width} × ${mode.height}`;
        if (display) {
          const modes = display.modes.filter((mode, index, all) => all.findIndex(other =>
            mode.width === other.width && mode.height === other.height) === index);
          if (!modes.some(mode => mode.width === display.width && mode.height === display.height)) modes.unshift(display);
          for (const mode of modes) {
            const option = document.createElement("option");
            option.value = `${mode.width}x${mode.height}`;
            option.textContent = label(mode) + (mode.width === display.width && mode.height === display.height ? "（corrente)" : "");
            option.disabled = !display.modes.some(value => value.width === mode.width && value.height === mode.height);
            select.appendChild(option);
          }
          select.value = `${display.width}x${display.height}`;
        } else {
          const option = document.createElement("option");
          option.textContent = resolutions?.state.status === "waiting" || !resolutions ? "Attesa delle informazioni del dispositivo controllato…" : "Dispositivo non supportato";
          option.value = ""; select.appendChild(option);
        }
      }
      if (display) select.value = `${display.width}x${display.height}`;
      select.disabled = !this.connected || !resolutions?.ready || !display?.modes.length || resolutions.pending;
      select.setAttribute("aria-busy", String(!!resolutions?.pending));
      const status = resolutions?.state.status;
      byId("display-resolution-feedback").textContent = !resolutions?.ready ? "Regolabile dopo la connessione."
        : resolutions.pending ? "Attesa della conferma del computer…"
        : ["failed", "timeout"].includes(status) ? "Regolazione non riuscita, riseleziona la risoluzione e riprova."
        : !display || !display.modes.length ? "Il dispositivo controllato non ha fornito risoluzioni disponibili per questo monitor."
        : resolutions.state.storageFailed ? "Risoluzione applicata, ma il browser non ha potuto salvare l’impostazione." : "";
      this.layout();
    }

    renderNetwork(stats) {
      if (panel.hidden || this.page !== "network") return;
      const finite = (value, suffix) => Number.isFinite(value) ? `${Math.round(value)}${suffix}` : "—";
      const values = {
        resolution: stats?.width && stats.height ? `${stats.width} × ${stats.height}` : "—",
        fps: finite(stats?.fps, " fps"),
        bitrate: Number.isFinite(stats?.received_bps) ? `${(stats.received_bps / 1000000).toFixed(2)} Mbps` : "—",
        loss: stats?.packets > 0 ? `${(stats.lost / stats.packets * 100).toFixed(1)}%` : "—",
        rtt: finite(stats?.rtt_ms, " ms"), buffer: finite(stats?.jitter_ms, " ms"),
        decode: finite(stats?.decode_ms, " ms"),
        route: stats?.route === "relay" ? `Relay${stats.protocol ? " / " + stats.protocol.toUpperCase() : ""}`
          : stats?.route === "direct" ? "Diretta" : "—",
      };
      for (const [key, value] of Object.entries(values)) byId(`network-${key}`).textContent = value;
      this.layout();
    }

    renderFiles(files) {
      const busy = (files?.items || []).filter(item => ["queued", "sending", "receiving", "saving"].includes(item.status)).length;
      byId("session-files-label").textContent = busy ? `Trasferimento file (${busy})` : "Trasferimento file";
      orb.classList.remove("has-file-updates");
      orb.setAttribute("aria-label", "Menu di controllo remoto");
      if (panel.hidden || this.page !== "files") {
        this.fileRows.clear();
        byId("file-transfer-list").replaceChildren();
        return;
      }
      this.renderLegacyFiles(files);
    }

    renderLegacyFiles(files) {
      const format = bytes => bytes < 1024 ? `${bytes} B` : bytes < 1024 * 1024
        ? `${(bytes / 1024).toFixed(1)} KiB` : bytes < 1024 * 1024 * 1024
        ? `${(bytes / (1024 * 1024)).toFixed(1)} MiB` : `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GiB`;
      const labels = { queued: "In coda", sending: "Invio in corso", receiving: "Ricezione in corso", saving: "Salvataggio in corso",
        completed: "Completato", cancelled: "Annullato", failed: "Non riuscito" };
      const items = files?.items || [], list = byId("file-transfer-list");
      byId("file-transfer-select").disabled = !files?.ready;
      byId("file-transfer-storage").textContent = !files || files.canWriteFiles
        ? "I file ricevuti vengono salvati nei download del browser durante il trasferimento. La posizione segue le impostazioni del browser."
        : "Questa pagina non può ricevere in streaming, usa un browser con Service Worker tramite HTTPS o localhost; puoi comunque inviare file.";
      byId("file-transfer-status").hidden = !!files?.ready;
      byId("file-transfer-status").textContent = files?.ready ? ""
        : files?.state === "unsupported" ? "Il dispositivo controllato non supporta ancora il trasferimento file con il Web Client, aggiorna il client controllato."
        : files?.state === "closed" ? "Canale file disconnesso, riconnettiti." : "Attesa della connessione del canale file…";
      byId("file-transfer-feedback").textContent = files?.error || "";
      byId("file-transfer-empty").hidden = items.length > 0;
      for (const [item, row] of this.fileRows) if (!items.includes(item)) {
        row.element.remove();
        this.fileRows.delete(item);
      }
      for (const item of items) {
        let row = this.fileRows.get(item);
        if (!row) {
          const element = document.createElement("li");
          element.className = "file-transfer-item";
          const header = document.createElement("div");
          header.className = "file-transfer-header";
          const name = document.createElement("strong"), detail = document.createElement("p");
          name.textContent = item.name;
          name.title = item.name;
          const progress = document.createElement("progress");
          progress.max = 1;
          progress.setAttribute("aria-label", `${item.name} Avanzamento trasferimento`);
          const actions = document.createElement("div");
          actions.className = "file-transfer-actions";
          const cancel = document.createElement("button"), remove = document.createElement("button");
          cancel.type = remove.type = "button";
          cancel.textContent = "Annulla";
          cancel.setAttribute("aria-label", `Annulla${item.direction === "send" ? "Invia" : "Ricevi"} ${item.name}`);
          remove.className = "file-transfer-remove";
          remove.textContent = "×";
          remove.setAttribute("aria-label", `Rimuovi record ${item.name}`);
          remove.title = "Rimuovi";
          cancel.addEventListener("click", () => files.cancel(item));
          remove.addEventListener("click", () => files.remove(item));
          header.append(name, remove);
          actions.append(cancel);
          element.append(header, detail, progress, actions);
          list.append(element);
          row = { element, detail, progress, actions, cancel, remove };
          this.fileRows.set(item, row);
        }
        const running = ["queued", "sending", "receiving", "saving"].includes(item.status);
        row.detail.textContent = `${item.direction === "send" ? "Invia" : "Ricevi"} · ${labels[item.status]} · ${format(item.bytes)} / ${format(item.total)}${item.detail ? " · " + item.detail : ""}`;
        row.progress.value = item.status === "completed" ? 1 : item.total ? item.bytes / item.total : 0;
        row.actions.hidden = !running;
        row.cancel.hidden = !running;
        row.remove.hidden = running;
      }
      this.layout();
    }

    beginDrag(event, target) {
      if (event.target.closest("#keyboard-close") || (event.button !== undefined && event.button !== 0) || this.drag) return;
      const touch = event.touches?.[0];
      if (event.touches && event.touches.length !== 1) return;
      const point = touch || event, rect = target.getBoundingClientRect();
      if (touch) event.preventDefault();
      control.cancelLocalInput();
      control.setDraggingPanel(true);
      this.drag = { target, touchId: touch?.identifier, x: point.clientX, y: point.clientY,
        left: rect.left, top: rect.top, moved: false };
      this.suppressClick = false;
    }

    moveDrag(event) {
      const drag = this.drag;
      if (!drag) return;
      const point = drag.touchId === undefined ? event : Array.from(event.touches || []).find(t => t.identifier === drag.touchId);
      if (!point || !Number.isFinite(point.clientX)) return;
      const dx = point.clientX - drag.x, dy = point.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 4) return;
      event.preventDefault();
      drag.moved = true;
      if (drag.target === orb) this.close();
      const position = this.place(drag.target, drag.left + dx, drag.top + dy);
      if (drag.target === orb) this.orbPosition = position;
      else if (drag.target === mouse) this.mousePosition = position;
      else this.keyboardPosition = position;
      this.layout();
    }

    endDrag(event, cancelled = false) {
      const drag = this.drag;
      if (!drag) return;
      if (event && !event.changedTouches && (drag.touchId !== undefined || event.button !== 0)) return;
      if (event?.changedTouches && !Array.from(event.changedTouches).some(t => t.identifier === drag.touchId)) return;
      this.drag = null;
      control.setDraggingPanel(false);
      this.suppressClick = drag.target === orb && (drag.moved || cancelled);
      if (drag.touchId !== undefined && !drag.moved && !cancelled && drag.target === orb) {
        this.toggle();
        this.suppressClick = true;
      }
    }

    toggle() {
      if (panel.hidden) this.showPage("main");
      else this.close();
    }

    bindEvents() {
      orb.addEventListener("click", () => {
        if (this.suppressClick) { this.suppressClick = false; return; }
        this.toggle();
      });
      for (const [target, draggable] of [[orb, orb], [byId("keyboard-header"), keyboard], [grip, mouse]]) {
        target.addEventListener("mousedown", event => this.beginDrag(event, draggable));
        target.addEventListener("touchstart", event => this.beginDrag(event, draggable), { passive: false });
      }
      grip.addEventListener("keydown", event => {
        const steps = { ArrowLeft: [-8, 0], ArrowRight: [8, 0], ArrowUp: [0, -8], ArrowDown: [0, 8] };
        const step = steps[event.key];
        if (!step) return;
        event.preventDefault();
        const rect = mouse.getBoundingClientRect();
        this.mousePosition = this.place(mouse, rect.left + step[0], rect.top + step[1]);
        this.layout();
      });
      document.addEventListener("mousemove", event => this.moveDrag(event));
      document.addEventListener("touchmove", event => this.moveDrag(event), { passive: false });
      document.addEventListener("mouseup", event => this.endDrag(event, event.crossdeskPointerCancelled));
      document.addEventListener("touchend", event => this.endDrag(event));
      document.addEventListener("touchcancel", event => this.endDrag(event, true));
      document.addEventListener("pointercancel", event => {
        if (event.pointerType !== "touch" && this.drag?.touchId === undefined) this.endDrag(null, true);
      });
      window.addEventListener("blur", () => { this.endDrag(null, true); control.cancelLocalInput(); });
      document.addEventListener("visibilitychange", () => {
        if (document.hidden) { this.endDrag(null, true); control.cancelLocalInput(); }
      });
      window.addEventListener("resize", () => this.layout());
      window.visualViewport?.addEventListener("resize", () => this.layout());
      window.visualViewport?.addEventListener("scroll", () => this.layout());
      shield.addEventListener("click", () => this.close());
      byId("session-menu-close").addEventListener("click", () => this.close());
      byId("session-menu-back").addEventListener("click", () => this.showPage("main"));
      byId("clipboard-manual").addEventListener("toggle", () => this.layout());
      byId("clipboard-automatic").addEventListener("click", () => void window.CrossDeskClipboard?.toggleAutomatic());
      byId("clipboard-send-local").addEventListener("click", () => void window.CrossDeskClipboard?.sendLocal());
      byId("clipboard-copy-remote").addEventListener("click", () => void window.CrossDeskClipboard?.writeRemote());
      byId("clipboard-send-text").addEventListener("click", async () => {
        const clipboard = window.CrossDeskClipboard;
        if (!clipboard?.ready) return;
        try {
          await clipboard.sendText(byId("clipboard-local").value);
          clipboard.feedback("Inviato al dispositivo remoto", { transient: true });
        } catch (error) { clipboard.feedback(error.message); }
      });
      byId("file-transfer-select").addEventListener("click", () => {
        if (!window.CrossDeskFiles?.ready) return;
        control.cancelLocalInput();
        this.filePickerSession = window.CrossDeskFiles;
        byId("file-transfer-input").click();
      });
      byId("file-transfer-input").addEventListener("cancel", () => { this.filePickerSession = null; });
      byId("file-transfer-input").addEventListener("change", event => {
        const files = this.filePickerSession;
        this.filePickerSession = null;
        try {
          // Like the desktop picker generation check, never send to a new
          // connection if the picker outlives its original session.
          if (files === window.CrossDeskFiles && files?.ready && event.target.files?.length)
            files.enqueue(Array.from(event.target.files));
        } catch (error) { files.error = error.message; files.notify(true); }
        finally { event.target.value = ""; }
      });
      panel.querySelectorAll("[data-page]").forEach(button => button.addEventListener("click", () => this.showPage(button.dataset.page)));
      panel.querySelectorAll("[data-setting]").forEach(button => button.addEventListener("click", () => {
        const settings = window.CrossDeskVideoSettings;
        if (!settings?.supported) return;
        session.requestVideoSettings({ ...settings.selection, [button.dataset.setting]: Number(button.dataset.value) });
      }));
      byId("video-settings-retry").addEventListener("click", () => {
        const values = window.CrossDeskVideoSettings?.requested;
        if (values) session.requestVideoSettings(values);
      });
      byId("display-resolution").addEventListener("change", event => {
        const context = this.resolutionContext;
        const [width, height] = event.target.value.split("x").map(Number);
        if (context) session.requestDisplayResolution(context.owner, context.displayId, context.displayKey, { width, height });
        this.renderResolutions(window.CrossDeskDisplayResolutions);
      });
      byId("session-keyboard").addEventListener("click", () => {
        this.close(); control.toggleVirtualKeyboard();
      });
      byId("session-mouse").addEventListener("click", () => {
        control.cancelLocalInput(); this.mouseVisible = !this.mouseVisible; this.close();
      });
      byId("session-mouse-mode").addEventListener("click", () => {
        const mode = control.state.mobileControlMode === "relative" ? "absolute" : "relative";
        control.setMouseMode(mode);
        this.updateMouse();
      });
      byId("session-disconnect-cancel").addEventListener("click", () => this.showPage("main"));
      byId("session-disconnect-confirm").addEventListener("click", () => session.disconnect());
      document.addEventListener("keydown", event => {
        if (panel.hidden || !this.active) return;
        if (event.key === "Escape") {
          event.preventDefault();
          this.page === "main" ? this.close() : this.showPage("main");
        } else if (event.key === "Tab") {
          const buttons = [...panel.querySelectorAll("button:not(:disabled), select:not(:disabled), textarea:not(:disabled), summary, a[href]")]
            .filter(el => el.getClientRects().length && (el.tagName === "SUMMARY" || !el.closest("details:not([open])")));
          const i = buttons.indexOf(document.activeElement), next = (i + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length;
          event.preventDefault(); buttons[next]?.focus();
        }
      });
    }
  }
  window.CrossDeskSessionControls = new SessionControls();
})();
